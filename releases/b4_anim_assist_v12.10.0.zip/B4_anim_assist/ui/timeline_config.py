"""Pure presentation model; layouts contain no scene or gesture state."""
import copy
import json
import math
import uuid

FAMILY_ORDER = ('tween', 'timing', 'curves', 'keys', 'pose', 'bake', 'motion')
# One table drives the stage tabs and the family filter. A stage only filters
# what the band shows; the saved layout and its tool settings never change.
STAGES = (
    ('ALL', 'All', None),
    ('BLOCK', 'Block', ('tween', 'keys')),
    ('SPLINE', 'Spline', ('curves',)),
    ('POLISH', 'Polish', ('timing', 'pose')),
    ('DELIVER', 'Deliver', ('bake', 'motion')),
)
STAGE_IDS = tuple(key for key, _label, _families in STAGES)
# Saved enum numbers; never renumber an existing stage.
STAGE_NUMBERS = {'ALL': 0, 'BLOCK': 1, 'SPLINE': 2, 'POLISH': 3, 'DELIVER': 4}
STAGE_KEYS = tuple(key for key, _label, families in STAGES if families)
SCHEMA_VERSION = 2
# Stage setups add about a third to each layout; keep room for 100 saved layouts.
RECORD_LIMIT = 1_400_000
MODES = ('HIDDEN', 'BUTTON', 'POPOUT', 'INLINE')
_B, _P, _I = 'BUTTON', 'POPOUT', 'INLINE'
# Fixed default toolsets, left to right in workflow order (owner decision:
# defaults never derive from a layout's All tools). Unlisted tools start Hidden.
STAGE_DEFAULTS = {
    'BLOCK': (('B25', _B), ('B50', _B), ('B75', _B), ('DRAG', _I), ('INBETWEEN', _B), ('INBETWEENS', _B),
              ('PUSH_PREV', _B), ('PULL_PREV', _B), ('PULL_NEXT', _B), ('PUSH_NEXT', _B),
              ('RANGE', _B), ('ALL', _B), ('ENDS', _B), ('GROW_LEFT', _B), ('GROW_RIGHT', _B),
              ('TYPE_KEYFRAME', _B), ('TYPE_BREAKDOWN', _B), ('TYPE_EXTREME', _B), ('TYPE_HOLD', _B),
              ('COPY_KEYS', _B), ('PASTE_KEYS', _B)),
    'SPLINE': (('REFERENCE', _B), ('FRAME', _P), ('NEIGHBORS', _I), ('EASE', _I), ('SMOOTH', _I),
               ('AMPLIFY', _P), ('HANDLE_CLAMPED', _B), ('HANDLE_VECTOR', _B), ('HANDLE_FREE', _B)),
    'POLISH': (('NUDGE_LEFT', _B), ('NUDGE_RIGHT', _B), ('SCALE_DRAG', _P), ('T80', _B), ('T90', _B),
               ('T110', _B), ('T120', _B), ('OFFSET_DRAG', _I), ('RIPPLE', _B), ('SNAP', _B),
               ('OPPOSITE', _B), ('MIRROR_SELECTED', _B), ('MIRROR_ACTIVE', _B), ('SWAP', _B)),
    'DELIVER': (('BAKE_STEP', _B), ('SMART_BAKE', _B), ('REDUCE', _B), ('BAKE_CLEANUP', _B),
                ('TRAIL_SHOW', _B), ('TRAIL_REFRESH', _B), ('TRAIL_DIAGNOSE', _B), ('TRAIL_HIDE', _B)),
}
# Action -> family, registered by timeline_catalog (keeps this module bpy- and catalogue-free).
_FAMILY = {}


def register_families(groups):
    _FAMILY.clear()
    _FAMILY.update({action: key for key, _label, actions in groups for action in actions if action})


def family_of(action):
    if not _FAMILY: raise ValueError('Toolbar families are not registered')
    return _FAMILY.get(action)


def stage_default(stage):
    pairs = STAGE_DEFAULTS[stage]
    return dict(order=[a for a, _m in pairs], tools={a: dict(mode=m, label_mode='LABEL') for a, m in pairs})


def _check_mode(action, mode, label_mode):
    if mode not in MODES or (action not in SLIDERS and mode in {'POPOUT', 'INLINE'}):
        raise ValueError('This tool does not support the selected display mode')
    if label_mode not in {'LABEL', 'ICON'}: raise ValueError('Choose Label or Icon')


def validate_stage(stage, raw, actions):
    """Sparse stage setup: visible tools only, in order; Hidden entries dropped."""
    if not isinstance(raw, dict): raise ValueError('Stage setup must be an object')
    order, tools_raw = raw.get('order', []), raw.get('tools', {})
    if not isinstance(order, list) or not isinstance(tools_raw, dict):
        raise ValueError('Stage setup must contain an order and tools')
    if any(not isinstance(k, str) for k in order) or len(set(order)) != len(order):
        raise ValueError('Stage tool order must contain unique action IDs')
    if any(k in actions and k not in order for k in tools_raw):
        raise ValueError('Every stage tool must appear in its order')
    allowed = set(stage_families(stage))
    result = dict(order=[], tools={})
    for action in order:
        entry = tools_raw.get(action, {})
        if action not in actions:  # Forward compatibility: keep unknown tools intact.
            if not isinstance(entry, dict): raise ValueError('Stage tool settings must be an object')
            result['order'].append(action); result['tools'][action] = copy.deepcopy(entry); continue
        if family_of(action) not in allowed:
            raise ValueError(f'{action} does not belong to the {stage_label(stage)} stage')
        if not isinstance(entry, dict): raise ValueError('Stage tool settings must be an object')
        mode, label_mode = entry.get('mode', 'BUTTON'), entry.get('label_mode', 'LABEL')
        _check_mode(action, mode, label_mode)
        if mode == 'HIDDEN': continue
        result['order'].append(action); result['tools'][action] = dict(mode=mode, label_mode=label_mode)
    for key, value in tools_raw.items():
        if key not in actions and key not in result['tools']:
            if not isinstance(value, dict): raise ValueError('Stage tool settings must be an object')
            result['tools'][key] = copy.deepcopy(value)
    return result
# (label, unit, neutral/default, display minimum, display maximum, hard minimum, hard maximum)
SLIDERS = {
    'DRAG': ('Breakdown', '%', 50., 0., 100., -100., 200.),
    'SMOOTH': ('Smooth', '%', 0., 0., 100., None, None),
    'NEIGHBORS': ('Neighbors', '%', 0., 0., 100., None, None),
    'FRAME': ('Reference', '%', 0., 0., 100., None, None),
    'EASE': ('Ease', '%', 0., 0., 100., None, None),
    'AMPLIFY': ('Push/Pull', '%', 0., -100., 200., None, None),
    'SCALE_DRAG': ('Timing Scale', '%', 100., 50., 200., 1., None),
    'OFFSET_DRAG': ('Timing Offset', 'f', 0., -10., 10., None, None),
}
RECOMMENDED_BUTTONS = {'B25', 'B50', 'B75', 'NUDGE_LEFT', 'NUDGE_RIGHT',
                       'COPY_KEYS', 'PASTE_KEYS', 'MIRROR_SELECTED', 'BAKE_STEP', 'TRAIL_SHOW'}


def tool_default(action):
    entry = dict(action=action, mode='HIDDEN', label_mode='LABEL', width=120.)
    if action in SLIDERS:
        label, unit, default, low, high, _min, _max = SLIDERS[action]
        entry.update(range_min=low, range_max=high, default=default, sensitivity=200.,
                     precision=1, snap_enabled=False, snap_step=1., presets=[],
                     overshoot_enabled=False)
    return entry


def recommended(actions):
    tools = {action: tool_default(action) for action in actions}
    for action in RECOMMENDED_BUTTONS & tools.keys(): tools[action]['mode'] = 'BUTTON'
    for action in ('DRAG', 'SMOOTH'):
        if action in tools: tools[action]['mode'] = 'INLINE'
    if 'SCALE_DRAG' in tools: tools['SCALE_DRAG']['mode'] = 'POPOUT'
    layout = dict(id='recommended', name='Recommended', order=list(actions), tools=tools,
                  stages={stage: stage_default(stage) for stage in STAGE_KEYS})
    return dict(schema_version=SCHEMA_VERSION, active=layout, active_saved_id='recommended', saved=[])


def finite(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(label+' must be a finite number')
    if abs(value) > 1e8: raise ValueError(label+' is outside the numeric display limit')
    return float(value)


def validate_tool(action, raw):
    if not isinstance(raw, dict): raise ValueError('Tool settings must be an object')
    result = tool_default(action)
    result.update({k: copy.deepcopy(v) for k, v in raw.items() if k in result})
    result['action'] = action
    if result['mode'] not in MODES or (action not in SLIDERS and result['mode'] in {'POPOUT','INLINE'}):
        raise ValueError('This tool does not support the selected display mode')
    if result['label_mode'] not in {'LABEL','ICON'}: raise ValueError('Choose Label or Icon')
    result['width'] = finite(result['width'], 'Slider width')
    if not 80 <= result['width'] <= 240: raise ValueError('Slider width must be 80–240')
    if action not in SLIDERS: return result
    for name in ('range_min','range_max','default','sensitivity','snap_step'):
        result[name] = finite(result[name], name)
    low, high = result['range_min'], result['range_max']
    if low >= high: raise ValueError('Minimum must be below maximum')
    if not low <= result['default'] <= high: raise ValueError('Default must be inside the slider range')
    hard_min, hard_max = SLIDERS[action][-2:]
    if hard_min is not None and low < hard_min: raise ValueError('Minimum is below the tool limit')
    if hard_max is not None and high > hard_max: raise ValueError('Maximum exceeds the tool limit')
    if not 10 <= result['sensitivity'] <= 2000: raise ValueError('Sensitivity must be 10–2000 pixels')
    if result['snap_step'] <= 0: raise ValueError('Snap step must be positive')
    if type(result['precision']) is not int or not 0 <= result['precision'] <= 4:
        raise ValueError('Precision must be 0–4 decimal places')
    for name in ('snap_enabled','overshoot_enabled'):
        if type(result[name]) is not bool: raise ValueError(name+' must be a checkbox')
    if not isinstance(result['presets'], list) or len(result['presets']) > 12:
        raise ValueError('Use at most 12 numeric presets')
    result['presets'] = [finite(v,'Preset') for v in result['presets']]
    if any(not low <= v <= high for v in result['presets']): raise ValueError('Presets must be inside the range')
    if not result['overshoot_enabled']:
        standard_min,standard_max=SLIDERS[action][3:5]
        if any(not standard_min<=v<=standard_max for v in [result['default'],*result['presets']]):
            raise ValueError('Enable Custom Range / Overshoot for these amounts')
    return result


def validate_layout(raw, actions):
    if not isinstance(raw, dict) or not isinstance(raw.get('tools'), dict):
        raise ValueError('Layout must contain tool settings')
    if not isinstance(raw.get('id'), str) or not raw['id']: raise ValueError('Layout identity is missing')
    name = validate_name(raw.get('name',''), allow_recommended=True)
    order = raw.get('order', [])
    if not isinstance(order,list) or any(not isinstance(k,str) for k in order) or len(set(order)) != len(order):
        raise ValueError('Tool order must contain unique action IDs')
    tools = {k: validate_tool(k, raw['tools'].get(k,{})) for k in actions}
    # Keep unknown tool records intact, hidden from current UI, for forward compatibility.
    unknown = {k: copy.deepcopy(v) for k,v in raw['tools'].items() if k not in actions}
    tools.update(unknown)
    order = order + [k for k in tools if k not in order]
    # Schema 1 layouts have no stages: they get the fixed defaults (migration).
    stages_raw = raw.get('stages', {})
    if not isinstance(stages_raw, dict): raise ValueError('Stage setups must be an object')
    stages = {stage: validate_stage(stage, stages_raw[stage], actions) if stage in stages_raw
              else stage_default(stage) for stage in STAGE_KEYS}
    stages.update({k: copy.deepcopy(v) for k, v in stages_raw.items() if k not in STAGE_KEYS})
    return dict(id=raw['id'], name=name, order=order, tools=tools, stages=stages)


def validate(record, actions):
    if (not isinstance(record,dict) or type(record.get('schema_version')) is not int
            or record['schema_version'] not in (1, SCHEMA_VERSION)):
        raise ValueError('Unsupported toolbar layout version; keep the original settings file')
    saved = record.get('saved')
    if not isinstance(saved,list) or len(saved) > 100: raise ValueError('Layout library must have at most 100 entries')
    active = validate_layout(record.get('active'),actions)
    items = [validate_layout(item,actions) for item in saved]
    identities = [x['id'] for x in items]
    names = [x['name'].casefold() for x in items]
    if len(set(identities)) != len(items) or len(set(names)) != len(items):
        raise ValueError('Saved layouts need unique names and identities')
    if 'recommended' in identities or 'recommended' in names:
        raise ValueError('Recommended is a protected built-in layout')
    selected = record.get('active_saved_id')
    if selected is not None and selected not in ['recommended',*identities]: selected = None
    return dict(schema_version=SCHEMA_VERSION,active=active,active_saved_id=selected,saved=items)


def decode(raw, actions):
    if not isinstance(raw,str) or len(raw) > RECORD_LIMIT: raise ValueError('Toolbar settings record is too large')
    try: record = json.loads(raw)
    except (ValueError, TypeError) as exc: raise ValueError('Toolbar settings are not valid JSON') from exc
    return validate(record,actions)


def encode(record, actions):
    raw=json.dumps(validate(record,actions),ensure_ascii=False,separators=(',',':'),sort_keys=True,allow_nan=False)
    if len(raw)>RECORD_LIMIT: raise ValueError('Layout library is too large; remove unused layouts')
    return raw


def from_legacy(actions, selected):
    result = recommended(actions)
    result['active_saved_id'] = None
    result['active'].update(id='custom',name='Custom')
    for key, tool in result['active']['tools'].items():
        tool['mode'] = ('POPOUT' if key in SLIDERS else 'BUTTON') if key in selected else 'HIDDEN'
    return result


def validate_name(name, allow_recommended=False):
    if not isinstance(name,str): raise ValueError('Enter a layout name')
    name = name.strip()
    if not name or len(name)>64: raise ValueError('Use a name with 1–64 characters')
    if not allow_recommended and name.casefold()=='recommended': raise ValueError('Recommended is reserved')
    return name


def save_as(record,name):
    name=validate_name(name)
    if any(x['name'].casefold()==name.casefold() for x in record['saved']):
        raise ValueError('That name already exists; choose another name or Update Saved Layout')
    item=copy.deepcopy(record['active']); item.update(id=uuid.uuid4().hex,name=name)
    record['saved'].append(item)
    record['active']=copy.deepcopy(item); record['active_saved_id']=item['id']


def load(record,ident,actions):
    item=recommended(actions)['active'] if ident=='recommended' else next((x for x in record['saved'] if x['id']==ident),None)
    if item is None: raise ValueError('Choose an existing saved layout')
    record['active']=copy.deepcopy(item); record['active_saved_id']=ident


def update_saved(record):
    ident=record['active_saved_id']
    if ident in {None,'recommended'}: raise ValueError('Use Save As to create your own layout')
    index=next((i for i,x in enumerate(record['saved']) if x['id']==ident),None)
    if index is None: raise ValueError('Saved layout no longer exists')
    record['saved'][index]=copy.deepcopy(record['active'])


def rename(record,ident,name):
    name=validate_name(name)
    if ident=='recommended': raise ValueError('Recommended cannot be renamed')
    if any(x['id']!=ident and x['name'].casefold()==name.casefold() for x in record['saved']):
        raise ValueError('That layout name already exists')
    item=next((x for x in record['saved'] if x['id']==ident),None)
    if item is None: raise ValueError('Choose an existing saved layout')
    item['name']=name
    if record['active_saved_id']==ident: record['active']['name']=name


def delete(record,ident):
    if ident=='recommended': raise ValueError('Recommended cannot be deleted')
    if not any(x['id']==ident for x in record['saved']): raise ValueError('Choose an existing saved layout')
    record['saved']=[x for x in record['saved'] if x['id']!=ident]
    if record['active_saved_id']==ident:
        record['active_saved_id']=None
        record['active'].update(id='custom',name='Custom')


def modified(record,actions):
    ident=record['active_saved_id']
    if ident is None: return True
    original=recommended(actions)['active'] if ident=='recommended' else next(x for x in record['saved'] if x['id']==ident)
    return record['active'] != original


def value_from_pointer(tool,start_value,delta,precise=False,snap=False):
    scale=(tool['range_max']-tool['range_min'])/tool['sensitivity']
    value=start_value+delta*scale*(.1 if precise else 1.)
    if tool['snap_enabled'] or snap: value=round(value/tool['snap_step'])*tool['snap_step']
    return min(tool['range_max'],max(tool['range_min'],value))


def effective_tool(action,tool):
    result=copy.deepcopy(tool)
    if action in SLIDERS and not tool['overshoot_enabled']:
        result['range_min'],result['range_max']=SLIDERS[action][3:5]
        result['default']=min(result['range_max'],max(result['range_min'],result['default']))
    return result


def stage_label(stage):
    return next((label for key,label,_ in STAGES if key==stage),'All')


def stage_families(stage):
    """Families a stage shows, in permanent order; unknown stages show all."""
    families=next((f for key,_,f in STAGES if key==stage),None)
    return FAMILY_ORDER if families is None else tuple(f for f in FAMILY_ORDER if f in families)


def stage_for_family(family):
    """The single stage that shows a family; All when no stage lists it."""
    return next((key for key,_,families in STAGES if families and family in families),'ALL')


def hidden_family_note(stage,family,family_label):
    """Explain why a configured family is absent from the row, or ''."""
    if family in stage_families(stage): return ''
    return (f'{family_label} is hidden in the {stage_label(stage)} stage; '
            f'choose All or {stage_label(stage_for_family(family))} to see it.')


def next_stage(stage,step):
    index=STAGE_IDS.index(stage) if stage in STAGE_IDS else 0
    return STAGE_IDS[(index+step)%len(STAGE_IDS)]


def _stage_setup(layout, stage):
    return layout.setdefault('stages', {}).setdefault(stage, stage_default(stage))


def stage_view(layout, stage):
    """(order, tools) a stage shows: per-stage mode/label over shared tool settings."""
    if stage not in STAGE_KEYS: return layout['order'], layout['tools']
    setup = layout.get('stages', {}).get(stage) or stage_default(stage)
    tools = {k: dict(v, mode='HIDDEN') if isinstance(v, dict) else v for k, v in layout['tools'].items()}
    for action in setup['order']:
        if isinstance(layout['tools'].get(action), dict) and isinstance(setup['tools'].get(action), dict):
            tools[action] = dict(layout['tools'][action], **setup['tools'][action])
    return list(setup['order']) + [k for k in layout['order'] if k not in setup['order']], tools


def reset_stage(record, stage):
    record['active'].setdefault('stages', {})[stage] = stage_default(stage)


def pin_target(stage, action):
    """The setup a pin changes: the stage when it shows the tool's family, else All."""
    return stage if stage in STAGE_KEYS and family_of(action) in stage_families(stage) else 'ALL'


def set_stage_tool(record, stage, action, mode=None, label_mode=None):
    """Change one tool's mode/label in All or a stage; showing a stage tool
    places it after the last visible tool of its family."""
    layout = record['active']
    if stage not in STAGE_KEYS:
        tool = layout['tools'][action]
        if mode is not None: tool['mode'] = mode
        if label_mode is not None: tool['label_mode'] = label_mode
        return
    setup = _stage_setup(layout, stage)
    current = setup['tools'].get(action)
    mode = mode or (current['mode'] if current else 'HIDDEN')
    label_mode = label_mode or (current['label_mode'] if current else 'LABEL')
    if mode == 'HIDDEN':
        if action in setup['order']: setup['order'].remove(action)
        setup['tools'].pop(action, None)
        return
    if action not in setup['order']:
        family = family_of(action)
        same = [i for i, a in enumerate(setup['order']) if family_of(a) == family]
        later = [i for i, a in enumerate(setup['order'])
                 if family_of(a) in FAMILY_ORDER and family in FAMILY_ORDER
                 and FAMILY_ORDER.index(family_of(a)) > FAMILY_ORDER.index(family)]
        index = same[-1] + 1 if same else (later[0] if later else len(setup['order']))
        setup['order'].insert(index, action)
    setup['tools'][action] = dict(mode=mode, label_mode=label_mode)


def stage_entries(record, stage, actions):
    """Settings rows for a setup: All lists every tool; a stage lists its families,
    visible tools in stage order, then hidden ones in catalogue order."""
    layout = record['active']
    order, tools = stage_view(layout, stage)
    allowed = None if stage not in STAGE_KEYS else set(stage_families(stage))
    return [dict(action=a, family=family_of(a), mode=tools[a]['mode'],
                 label_mode=tools[a]['label_mode'], width=tools[a]['width'])
            for a in order if a in actions and (allowed is None or family_of(a) in allowed)]


def apply_entries(record, stage, entries, actions):
    """Store settings rows back; widths are shared by All and every stage."""
    layout = record['active']
    for entry in entries:
        layout['tools'][entry['action']]['width'] = entry['width']
    listed = [e['action'] for e in entries]
    if stage not in STAGE_KEYS:
        layout['order'] = listed + [k for k in layout['order'] if k not in listed]
        for entry in entries:
            layout['tools'][entry['action']].update(mode=entry['mode'], label_mode=entry['label_mode'])
        return
    old = _stage_setup(layout, stage)
    visible = [e for e in entries if e['mode'] != 'HIDDEN']
    setup = dict(order=[e['action'] for e in visible],
                 tools={e['action']: dict(mode=e['mode'], label_mode=e['label_mode']) for e in visible})
    for key in old['order']:
        if key not in actions and key not in setup['tools']:
            setup['order'].append(key); setup['tools'][key] = copy.deepcopy(old['tools'].get(key, {}))
    for key, value in old['tools'].items():
        if key not in actions and key not in setup['tools']: setup['tools'][key] = copy.deepcopy(value)
    layout['stages'][stage] = setup


def toolbar_layout(width,height,row_height,at_top,record,groups,labels,measure,stage='ALL'):
    """Bounded presentation only; never modify the saved layout on overflow."""
    scale=row_height/28.
    gap=3*scale; pad=5*scale
    y=max(0,height-row_height) if at_top else 0
    h=max(1,min(height,row_height)-4*scale)
    families={key:(label,{a for a in actions if a is not None}) for key,label,actions in groups}
    utilities=[('SEARCH','','Find'),('MORE','','More'),('SETTINGS','','Settings')]
    utility_widths=[max(24*scale,measure(label)+2*pad) for _,_,label in utilities]
    if sum(utility_widths)+4*gap>width:
        utilities=[(kind,key,'') for kind,key,_ in utilities]
        utility_widths=[24*scale]*3
    budget=max(0,width-sum(utility_widths)-4*gap)
    # Stage tabs lead the band. The choice between tabs and the single cycle
    # button never depends on the selected stage, so switching stages cannot
    # swap one for the other under the cursor. The cycle button keeps one key.
    tabs=[('STAGE',key,label,max(24*scale,measure(label)+2*pad)) for key,label,_ in STAGES]
    label=stage_label(stage)
    if measure(label)+2*pad>budget*.5: label=label[0]
    cycle=[('STAGE_CYCLE','CYCLE',label,max(24*scale,measure(label)+2*pad))]

    def compose(shown,compact=False,demote=False,no_families=False):
        specs=[]
        order,tools=stage_view(record['active'],shown)
        for family in stage_families(shown):
            label,known=families[family]
            selected=[a for a in order if a in known and tools[a]['mode']!='HIDDEN']
            if not no_families:
                specs.append(('MENU',family,label,measure(label)+(6 if compact else 10)*scale))
            for action in selected:
                tool=tools[action]; mode=tool['mode']
                label=SLIDERS[action][0] if action in SLIDERS else labels.get(action,action.replace('_',' ').title())
                if mode=='INLINE' and not demote:
                    label='' if compact or tool['label_mode']=='ICON' else label
                    w=(80 if compact else tool['width'])*scale+measure(label)+(46 if compact else 54)*scale
                    kind='SLIDER'
                else:
                    kind='POPOUT' if mode in {'POPOUT','INLINE'} else 'ACTION'
                    if tool['label_mode']=='ICON': label=''
                    w=max(24*scale,measure(label)+2*pad)
                specs.append((kind,action,label,w))
                if action in SLIDERS:
                    for value in tool['presets']:
                        text=f'{value:g}'
                        specs.append(('PRESET',action+':'+text,text,max(24*scale,measure(text)+2*pad)))
        return specs

    fits=lambda specs:sum(i[3]+gap for i in specs)<=budget
    # Tabs only when All's full layout fits beside them, as in 12.9.x. The
    # choice never depends on the selected stage; a wider stage toolset
    # compacts or overflows into More instead of moving the tabs.
    lead=tabs if fits(tabs+compose('ALL')) else cycle
    candidates=[lead+body for body in (compose(stage),compose(stage,compact=True),
                                       compose(stage,compact=True,demote=True),
                                       compose(stage,compact=True,demote=True,no_families=True))]
    specs=next((c for c in candidates if fits(c)),candidates[-1])
    controls=[]; x=gap
    for kind,key,label,w in specs:
        if x+w>budget: continue
        controls.append((kind,key,label,(x,y+2*scale,w,h)))
        x+=w+gap
    x=max(x,width-sum(utility_widths)-3*gap)
    for (kind,key,label),w in zip(utilities,utility_widths):
        if x+w<=width:
            controls.append((kind,key,label,(x,y+2*scale,w,h)))
        x+=w+gap
    return controls


def slider_parts(rect,label,measure,scale):
    x,y,w,h=rect
    label_width=measure(label)+4*scale if label else 0
    reset=(x+w-18*scale,y,18*scale,h)
    value=(reset[0]-34*scale,y,34*scale,h)
    track=(x+label_width+3*scale,y+3*scale,max(1,value[0]-x-label_width-6*scale),h-6*scale)
    return track,value,reset
