# BoneCraft CATS UV Tools Credits

BoneCraft UV methods are integrated into the CATS Material Combiner workflow.
This integration reimplements atlas-focused UV method behavior for BoneCraft and
does not vendor the full UVToolkit add-on.

## Lineage

- CATS workflow lineage inspired by the original Cats Blender Plugin by
  GiveMeAllYourCats / absolute-quantum contributors.
  Source: https://github.com/absolute-quantum/cats-blender-plugin
  License: MIT License.
- Material atlas / combiner lineage credits Grim-es/material-combiner-addon and
  its contributors.
  Source: https://github.com/Grim-es/material-combiner-addon
  License: GPL-3.0.
- UV method ideas credit UV Toolkit by Alexander Belyakov and the
  oRazeD/UVToolkit archival maintenance effort.
  Source: https://github.com/oRazeD/UVToolkit
  License noted by manifest: GPL-3.0-or-later.

## Modification Notice

These BoneCraft UV tools are adapted for the BoneCraft CATS Material Combiner
workflow. They use BoneCraft operator names and are not a drop-in copy of
UVToolkit.
